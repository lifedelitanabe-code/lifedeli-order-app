# ライフデリ田辺店 Web注文アプリ

スマホ優先のWeb注文フォームです。注文送信時は、ブラウザからサーバー側APIへ送信し、Gmail SMTPを使って店舗メールへ通知します。

## 主な仕様

- 利用者1名 / 夫婦など2名分に対応
- 昼食・夕食を別々に設定
- 昼・夕それぞれ希望曜日と個数を設定
- 入力 → 確認 → 完了の3ステップ
- 送信中はボタン無効化（二重送信防止）
- 送信失敗時は入力内容を保持
- Gmail認証情報はフロントエンドに含めない

## Vercelで設定する環境変数

- `GMAIL_USER`：アプリパスワードを作成したGmailアドレス
- `GMAIL_APP_PASSWORD`：Googleで発行した16文字のアプリパスワード（空白なし）
- `ORDER_TO_EMAIL`：`lifedeli.tanabe@gmail.com`

※ 本物のパスワードは `.env` やコードに書かず、Vercelの Environment Variables に登録してください。

## Vercelに公開する流れ

1. このフォルダ一式をGitHubのPrivateリポジトリへアップロード
2. Vercelで `Add New` → `Project`
3. GitHubリポジトリをImport
4. `Settings` → `Environment Variables` で上記3つを登録
5. Deploy / Redeploy
6. Webフォームからテスト注文

## メール件名

`【Web注文】利用者名／開始希望日`

## メール本文

本文冒頭に `【Web注文テスト】` を表示します。

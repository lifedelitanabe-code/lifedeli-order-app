import './globals.css';

export const metadata = {
  title: 'ライフデリ田辺店｜Web注文',
  description: 'ライフデリ田辺店 Web注文フォーム',
};

export default function RootLayout({ children }) {
  return (
    <html lang="ja">
      <body>{children}</body>
    </html>
  );
}

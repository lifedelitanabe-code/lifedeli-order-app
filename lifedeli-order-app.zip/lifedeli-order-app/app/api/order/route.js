import nodemailer from 'nodemailer';

export const runtime = 'nodejs';

const DAYS_ORDER = ['月', '火', '水', '木', '金', '土', '日'];

function normalizeDays(days = []) {
  return DAYS_ORDER.filter((d) => days.includes(d));
}

function clean(value = '') {
  return String(value).trim();
}

function validate(data) {
  if (!data || typeof data !== 'object') return '入力内容が正しくありません。';
  if (!clean(data.applicantName)) return '申込者名がありません。';
  if (!clean(data.relationship)) return '利用者との関係がありません。';
  if (!Array.isArray(data.people) || data.people.length < 1 || data.people.length > 2) return '利用者情報が正しくありません。';

  for (const p of data.people) {
    if (!clean(p.name) || !clean(p.phone) || !clean(p.address) || !clean(p.startDate)) return '必須項目が不足しています。';
    if (!p.lunchEnabled && !p.dinnerEnabled) return '昼食または夕食を選択してください。';
    if (p.lunchEnabled && normalizeDays(p.lunchDays).length === 0) return '昼食の曜日を選択してください。';
    if (p.dinnerEnabled && normalizeDays(p.dinnerDays).length === 0) return '夕食の曜日を選択してください。';
  }
  return '';
}

function mealText(enabled, days, qty) {
  if (!enabled) return 'なし';
  return `${normalizeDays(days).join('・')}曜日／1回 ${Number(qty || 1)}個`;
}

function buildText(data) {
  const peopleText = data.people.map((p, index) => {
    const prefix = data.people.length > 1 ? `【利用者${index + 1}】\n` : '';
    return [
      prefix + `利用者：${clean(p.name)}`,
      `電話番号：${clean(p.phone)}`,
      `住所：${clean(p.address)}`,
      `商品：${clean(p.product)}／${clean(p.setType)}`,
      `【昼食】${mealText(p.lunchEnabled, p.lunchDays, p.lunchQty)}`,
      `【夕食】${mealText(p.dinnerEnabled, p.dinnerDays, p.dinnerQty)}`,
      `開始希望日：${clean(p.startDate)}`,
    ].join('\n');
  }).join('\n\n');

  return [
    '【Web注文テスト】',
    '',
    peopleText,
    '',
    `申込者：${clean(data.applicantName)}`,
    `関係：${clean(data.relationship)}`,
    `緊急連絡先：${clean(data.emergencyContact) || 'なし'}`,
    `ご要望：${clean(data.requests) || 'なし'}`,
  ].join('\n');
}

function escapeHtml(value = '') {
  return String(value)
    .replaceAll('&', '&amp;')
    .replaceAll('<', '&lt;')
    .replaceAll('>', '&gt;')
    .replaceAll('"', '&quot;')
    .replaceAll("'", '&#039;');
}

function buildHtml(data) {
  const peopleHtml = data.people.map((p, index) => `
    <div style="border:1px solid #e6e0d7;border-radius:12px;padding:16px;margin:0 0 16px;background:#fffdf9;">
      ${data.people.length > 1 ? `<h3 style="margin:0 0 12px;">利用者${index + 1}</h3>` : ''}
      <p><b>利用者：</b>${escapeHtml(clean(p.name))}</p>
      <p><b>電話番号：</b>${escapeHtml(clean(p.phone))}</p>
      <p><b>住所：</b>${escapeHtml(clean(p.address))}</p>
      <p><b>商品：</b>${escapeHtml(clean(p.product))}／${escapeHtml(clean(p.setType))}</p>
      <p><b>【昼食】</b>${escapeHtml(mealText(p.lunchEnabled, p.lunchDays, p.lunchQty))}</p>
      <p><b>【夕食】</b>${escapeHtml(mealText(p.dinnerEnabled, p.dinnerDays, p.dinnerQty))}</p>
      <p><b>開始希望日：</b>${escapeHtml(clean(p.startDate))}</p>
    </div>
  `).join('');

  return `
    <div style="font-family:-apple-system,BlinkMacSystemFont,'Segoe UI','Noto Sans JP',sans-serif;color:#222;line-height:1.7;max-width:680px;margin:auto;">
      <div style="background:#fff1d6;border-radius:12px;padding:12px 16px;margin-bottom:18px;font-weight:700;">【Web注文テスト】</div>
      ${peopleHtml}
      <div style="border-top:2px solid #eee;padding-top:12px;">
        <p><b>申込者：</b>${escapeHtml(clean(data.applicantName))}</p>
        <p><b>関係：</b>${escapeHtml(clean(data.relationship))}</p>
        <p><b>緊急連絡先：</b>${escapeHtml(clean(data.emergencyContact) || 'なし')}</p>
        <p><b>ご要望：</b>${escapeHtml(clean(data.requests) || 'なし')}</p>
      </div>
    </div>
  `;
}

export async function POST(request) {
  try {
    const data = await request.json();
    const validationError = validate(data);
    if (validationError) {
      return Response.json({ ok: false, message: validationError }, { status: 400 });
    }

    const user = process.env.GMAIL_USER;
    const pass = process.env.GMAIL_APP_PASSWORD;
    const to = process.env.ORDER_TO_EMAIL;

    if (!user || !pass || !to) {
      console.error('Missing required email environment variables.');
      return Response.json({ ok: false, message: 'メール設定が完了していません。' }, { status: 500 });
    }

    const transporter = nodemailer.createTransport({
      host: 'smtp.gmail.com',
      port: 465,
      secure: true,
      auth: { user, pass },
    });

    const first = data.people[0];
    const subject = `【Web注文】${clean(first.name)}／${clean(first.startDate)}`;

    await transporter.sendMail({
      from: `ライフデリ田辺店 Web注文 <${user}>`,
      to,
      subject,
      text: buildText(data),
      html: buildHtml(data),
      replyTo: user,
    });

    return Response.json({ ok: true });
  } catch (error) {
    console.error('Order email send failed:', error);
    return Response.json({ ok: false, message: '送信に失敗しました。' }, { status: 500 });
  }
}

'use client';

import { useMemo, useState } from 'react';

const DAYS = ['月', '火', '水', '木', '金', '土', '日'];
const PRODUCTS = ['普通食', 'カロリー調整食', '透析食', '腎臓食', 'やわらか食', 'ムース食'];
const SET_TYPES = ['おかずのみ', 'ごはんセット'];

const blankPerson = () => ({
  name: '',
  phone: '',
  address: '',
  product: '普通食',
  setType: 'おかずのみ',
  lunchEnabled: true,
  lunchDays: [],
  lunchQty: 1,
  dinnerEnabled: false,
  dinnerDays: [],
  dinnerQty: 1,
  startDate: '',
});

export default function Home() {
  const [step, setStep] = useState('input');
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState('');
  const [form, setForm] = useState({
    applicantName: '',
    relationship: '',
    emergencyContact: '',
    requests: '',
    people: [blankPerson()],
  });

  const canAddSecond = form.people.length < 2;

  const updateTop = (key, value) => {
    setForm((prev) => ({ ...prev, [key]: value }));
  };

  const updatePerson = (index, key, value) => {
    setForm((prev) => {
      const people = [...prev.people];
      people[index] = { ...people[index], [key]: value };
      return { ...prev, people };
    });
  };

  const toggleDay = (index, mealKey, day) => {
    const key = mealKey === 'lunch' ? 'lunchDays' : 'dinnerDays';
    const current = form.people[index][key];
    const next = current.includes(day)
      ? current.filter((d) => d !== day)
      : [...current, day];
    updatePerson(index, key, next);
  };

  const validationMessage = useMemo(() => {
    if (!form.applicantName.trim()) return '申込者のお名前を入力してください。';
    if (!form.relationship.trim()) return '利用者との関係を入力してください。';

    for (let i = 0; i < form.people.length; i++) {
      const p = form.people[i];
      const label = form.people.length === 1 ? '利用者' : `利用者${i + 1}`;
      if (!p.name.trim()) return `${label}のお名前を入力してください。`;
      if (!p.phone.trim()) return `${label}の電話番号を入力してください。`;
      if (!p.address.trim()) return `${label}の住所を入力してください。`;
      if (!p.startDate) return `${label}の開始希望日を選択してください。`;
      if (!p.lunchEnabled && !p.dinnerEnabled) return `${label}は昼食か夕食のどちらかを選んでください。`;
      if (p.lunchEnabled && p.lunchDays.length === 0) return `${label}の昼食の希望曜日を選んでください。`;
      if (p.dinnerEnabled && p.dinnerDays.length === 0) return `${label}の夕食の希望曜日を選んでください。`;
    }
    return '';
  }, [form]);

  const goConfirm = (e) => {
    e.preventDefault();
    setError('');
    if (validationMessage) {
      setError(validationMessage);
      window.scrollTo({ top: 0, behavior: 'smooth' });
      return;
    }
    setStep('confirm');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const submitOrder = async () => {
    setSubmitting(true);
    setError('');
    try {
      const res = await fetch('/api/order', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(form),
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok || !data.ok) throw new Error(data.message || '送信に失敗しました。');
      setStep('done');
      window.scrollTo({ top: 0, behavior: 'smooth' });
    } catch (err) {
      setError('送信に失敗しました。入力内容は残っています。時間をおいてもう一度お試しいただくか、店舗へ直接ご連絡ください。');
      window.scrollTo({ top: 0, behavior: 'smooth' });
    } finally {
      setSubmitting(false);
    }
  };

  if (step === 'done') {
    return (
      <main className="page-shell">
        <section className="card done-card">
          <div className="checkmark">✓</div>
          <h1>送信が完了しました</h1>
          <p>お申込み内容をライフデリ田辺店へ送信しました。</p>
          <p className="muted">内容確認後、店舗よりご連絡させていただきます。</p>
        </section>
      </main>
    );
  }

  return (
    <main className="page-shell">
      <header className="hero">
        <p className="eyebrow">ライフデリ田辺店</p>
        <h1>Web注文フォーム</h1>
        <p>昼食・夕食を曜日ごとに分けてお申込みいただけます。</p>
      </header>

      {error && <div className="alert">{error}</div>}

      {step === 'input' ? (
        <form onSubmit={goConfirm} className="stack">
          <section className="card">
            <h2>申込者情報</h2>
            <Field label="申込者のお名前" required>
              <input value={form.applicantName} onChange={(e) => updateTop('applicantName', e.target.value)} placeholder="例：田辺 太郎" />
            </Field>
            <Field label="利用者との関係" required>
              <input value={form.relationship} onChange={(e) => updateTop('relationship', e.target.value)} placeholder="例：本人・長女・ケアマネジャー" />
            </Field>
            <Field label="緊急連絡先">
              <input value={form.emergencyContact} onChange={(e) => updateTop('emergencyContact', e.target.value)} placeholder="例：090-1234-5678（長女）" />
            </Field>
          </section>

          {form.people.map((person, index) => (
            <section className="card" key={index}>
              <div className="section-title-row">
                <h2>{form.people.length === 1 ? '利用者情報' : `利用者 ${index + 1}`}</h2>
                {index === 1 && (
                  <button type="button" className="link-button danger" onClick={() => setForm((p) => ({ ...p, people: p.people.slice(0, 1) }))}>
                    2人目を削除
                  </button>
                )}
              </div>

              <Field label="利用者のお名前" required>
                <input value={person.name} onChange={(e) => updatePerson(index, 'name', e.target.value)} placeholder="例：田辺 花子" />
              </Field>
              <Field label="電話番号" required>
                <input inputMode="tel" value={person.phone} onChange={(e) => updatePerson(index, 'phone', e.target.value)} placeholder="例：0739-00-0000" />
              </Field>
              <Field label="お届け先住所" required>
                <textarea rows="3" value={person.address} onChange={(e) => updatePerson(index, 'address', e.target.value)} placeholder="例：和歌山県田辺市〇〇 1-2-3" />
              </Field>

              <div className="two-col">
                <Field label="商品" required>
                  <select value={person.product} onChange={(e) => updatePerson(index, 'product', e.target.value)}>
                    {PRODUCTS.map((x) => <option key={x}>{x}</option>)}
                  </select>
                </Field>
                <Field label="内容" required>
                  <select value={person.setType} onChange={(e) => updatePerson(index, 'setType', e.target.value)}>
                    {SET_TYPES.map((x) => <option key={x}>{x}</option>)}
                  </select>
                </Field>
              </div>

              <MealBox title="昼食" enabled={person.lunchEnabled} onEnabled={(v) => updatePerson(index, 'lunchEnabled', v)} days={person.lunchDays} onToggleDay={(d) => toggleDay(index, 'lunch', d)} qty={person.lunchQty} onQty={(v) => updatePerson(index, 'lunchQty', v)} />
              <MealBox title="夕食" enabled={person.dinnerEnabled} onEnabled={(v) => updatePerson(index, 'dinnerEnabled', v)} days={person.dinnerDays} onToggleDay={(d) => toggleDay(index, 'dinner', d)} qty={person.dinnerQty} onQty={(v) => updatePerson(index, 'dinnerQty', v)} />

              <Field label="開始希望日" required>
                <input type="date" value={person.startDate} onChange={(e) => updatePerson(index, 'startDate', e.target.value)} />
              </Field>
            </section>
          ))}

          {canAddSecond && (
            <button type="button" className="secondary-button" onClick={() => setForm((p) => ({ ...p, people: [...p.people, blankPerson()] }))}>
              ＋ 夫婦など2人分を申し込む
            </button>
          )}

          <section className="card">
            <Field label="ご要望・備考">
              <textarea rows="5" value={form.requests} onChange={(e) => updateTop('requests', e.target.value)} placeholder="配達時のご要望、食事についての連絡事項など" />
            </Field>
          </section>

          <button className="primary-button" type="submit">入力内容を確認する</button>
          <p className="footnote">送信前に確認画面が表示されます。</p>
        </form>
      ) : (
        <section className="stack">
          <section className="card">
            <h2>入力内容の確認</h2>
            <ReviewRow label="申込者" value={form.applicantName} />
            <ReviewRow label="関係" value={form.relationship} />
            <ReviewRow label="緊急連絡先" value={form.emergencyContact || '未入力'} />
          </section>

          {form.people.map((p, i) => (
            <section className="card" key={i}>
              <h2>{form.people.length === 1 ? '利用者情報' : `利用者 ${i + 1}`}</h2>
              <ReviewRow label="利用者名" value={p.name} />
              <ReviewRow label="電話番号" value={p.phone} />
              <ReviewRow label="住所" value={p.address} />
              <ReviewRow label="商品" value={`${p.product}／${p.setType}`} />
              <ReviewRow label="昼食" value={p.lunchEnabled ? `${p.lunchDays.join('・')}曜日／${p.lunchQty}個` : 'なし'} />
              <ReviewRow label="夕食" value={p.dinnerEnabled ? `${p.dinnerDays.join('・')}曜日／${p.dinnerQty}個` : 'なし'} />
              <ReviewRow label="開始希望日" value={p.startDate} />
            </section>
          ))}

          <section className="card">
            <ReviewRow label="ご要望" value={form.requests || 'なし'} />
          </section>

          <div className="button-row">
            <button className="secondary-button" type="button" disabled={submitting} onClick={() => { setError(''); setStep('input'); }}>
              修正する
            </button>
            <button className="primary-button" type="button" disabled={submitting} onClick={submitOrder}>
              {submitting ? '送信中…' : 'この内容で送信する'}
            </button>
          </div>
        </section>
      )}
    </main>
  );
}

function Field({ label, required, children }) {
  return (
    <label className="field">
      <span>{label}{required && <em>必須</em>}</span>
      {children}
    </label>
  );
}

function MealBox({ title, enabled, onEnabled, days, onToggleDay, qty, onQty }) {
  return (
    <div className="meal-box">
      <label className="meal-toggle">
        <input type="checkbox" checked={enabled} onChange={(e) => onEnabled(e.target.checked)} />
        <strong>{title}を注文する</strong>
      </label>
      {enabled && (
        <div className="meal-body">
          <p className="small-label">希望曜日</p>
          <div className="days">
            {DAYS.map((day) => (
              <button type="button" key={day} className={days.includes(day) ? 'day active' : 'day'} onClick={() => onToggleDay(day)}>{day}</button>
            ))}
          </div>
          <label className="qty-label">
            1回あたりの個数
            <select value={qty} onChange={(e) => onQty(Number(e.target.value))}>
              {[1,2,3,4,5].map((n) => <option key={n} value={n}>{n}個</option>)}
            </select>
          </label>
        </div>
      )}
    </div>
  );
}

function ReviewRow({ label, value }) {
  return (
    <div className="review-row">
      <span>{label}</span>
      <strong>{value}</strong>
    </div>
  );
}
